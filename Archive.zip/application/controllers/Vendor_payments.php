<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vendor_payments extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        
        // Check if user is logged in and has admin or staff role
        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }
        
        $user_role = $this->session->userdata('role');
        if ($user_role !== 'admin' && $user_role !== 'staff') {
            show_404();
        }
        
        // Load required models
        $this->load->model('Vendor_payments_model');
        $this->load->model('Vendor_model');
        $this->load->library('form_validation');
        $this->load->library('pagination');
        
        // Load additional models for staff sidebar
        if ($user_role === 'staff') {
            $this->load->model('User_model');
            $this->load->model('Order_model');
            $this->load->model('Product_model');
            $this->load->model('Support_ticket_model');
            $this->load->model('Recharge_request_model');
            $this->load->model('Lead_model');
            $this->load->model('Customer_reminder_model');
            $this->load->model('Notification_model');
            $this->load->model('Admin_message_model');
            $this->load->model('Wallet_model');
        }
    }
    
    /**
     * Set notification counts for staff sidebar
     */
    private function set_notification_counts(&$data) {
        $user_id = $this->session->userdata('user_id');
        
        // Set notification counts for sidebar
        $data['new_leads'] = $this->Lead_model->count_leads_by_status('new');
        $data['pending_tickets'] = $this->Support_ticket_model->count_tickets_by_status('open');
        $data['pending_recharge_requests'] = $this->Recharge_request_model->count_requests_by_status('pending');
        $data['active_reminders'] = $this->Customer_reminder_model->count_reminders_by_status('active');
        $data['unread_messages'] = $this->Admin_message_model->get_unread_count();
        $data['unread_notifications'] = $this->Notification_model->get_unread_count($user_id, 'staff');
    }
    
    // Main listing page
    public function index() {
        $data['title'] = 'Vendor Payments';
        $data['active_page'] = 'vendor_payments';
        
        // Set notification counts for staff sidebar
        if ($this->session->userdata('role') === 'staff') {
            $this->set_notification_counts($data);
        }
        
        // Get filters from URL parameters
        $filters = array(
            'vendor' => $this->input->get('vendor'),
            'status' => $this->input->get('status'),
            'mode' => $this->input->get('mode'),
            'date_from' => $this->input->get('date_from'),
            'date_to' => $this->input->get('date_to')
        );
        
        // Pagination configuration
        $config['base_url'] = base_url('vendor_payments');
        $config['total_rows'] = $this->Vendor_payments_model->count_all_payments($filters);
        $config['per_page'] = 20;
        $config['page_query_string'] = TRUE;
        $config['query_string_segment'] = 'page';
        
        // Pagination styling
        $config['full_tag_open'] = '<nav><ul class="pagination justify-content-center">';
        $config['full_tag_close'] = '</ul></nav>';
        $config['first_tag_open'] = '<li class="page-item">';
        $config['first_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_tag_close'] = '</li>';
        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tag_close'] = '</li>';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><span class="page-link">';
        $config['cur_tag_close'] = '</span></li>';
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $config['anchor_class'] = 'page-link';
        
        $this->pagination->initialize($config);
        
        // Get current page
        $page = $this->input->get('page') ? $this->input->get('page') : 0;
        $offset = $page * $config['per_page'];
        
        // Get payments data
        $data['payments'] = $this->Vendor_payments_model->get_all_payments($config['per_page'], $offset, $filters);
        $data['vendor_summary'] = $this->Vendor_payments_model->get_vendor_summary();
        $data['overall_summary'] = $this->Vendor_payments_model->get_overall_summary();
        $data['vendors'] = $this->Vendor_payments_model->get_unique_vendors();
        $data['modes'] = $this->Vendor_payments_model->get_payment_modes();
        $data['statuses'] = $this->Vendor_payments_model->get_payment_statuses();
        $data['filters'] = $filters;
        $data['pagination'] = $this->pagination->create_links();
        
        // Load views based on user role
        if ($this->session->userdata('role') === 'admin') {
            $this->load->view('admin/includes/header', $data);
            $this->load->view('admin/includes/sidebar');
            $this->load->view('vendor_payments/list', $data);
            $this->load->view('admin/includes/footer');
        } else {
            $this->load->view('staff/includes/header', $data);
            $this->load->view('staff/includes/sidebar');
            $this->load->view('vendor_payments/list', $data);
            $this->load->view('staff/includes/footer');
        }
    }
    
    // Add new payment form
    public function add() {
        $data['title'] = 'Add Vendor Payment';
        $data['active_page'] = 'vendor_payments';
        $data['modes'] = $this->Vendor_payments_model->get_payment_modes();
        $data['statuses'] = $this->Vendor_payments_model->get_payment_statuses();
        $data['vendors'] = $this->Vendor_model->get_active_vendors();
        
        // Set notification counts for staff sidebar
        if ($this->session->userdata('role') === 'staff') {
            $this->set_notification_counts($data);
        }
        
        if ($this->input->post()) {
            $this->form_validation->set_rules('date', 'Date', 'required');
            $this->form_validation->set_rules('sender', 'Sender', 'required|trim');
            $this->form_validation->set_rules('receiver', 'Receiver', 'required|trim');
            $this->form_validation->set_rules('mode', 'Payment Mode', 'required|in_list[Zelle,Cash App,Venmo]');
            $this->form_validation->set_rules('amount', 'Amount', 'required|trim');
            $this->form_validation->set_rules('status', 'Status', 'required|in_list[Pending,Approved,Declined]');
            $this->form_validation->set_rules('vendor_id', 'Vendor', 'required|numeric');
            
            if ($this->form_validation->run() == TRUE) {
                $payment_data = array(
                    'date' => $this->input->post('date'),
                    'sender' => $this->input->post('sender'),
                    'receiver' => $this->input->post('receiver'),
                    'mode' => $this->input->post('mode'),
                    'amount' => $this->input->post('amount'),
                    'status' => $this->input->post('status'),
                    'vendor_id' => $this->input->post('vendor_id'),
                    'created_by' => $this->session->userdata('user_id')
                );
                
                $payment_id = $this->Vendor_payments_model->add_payment($payment_data);
                
                if ($payment_id) {
                    $this->session->set_flashdata('success', 'Vendor payment added successfully.');
                    redirect('vendor_payments');
                } else {
                    $this->session->set_flashdata('error', 'Failed to add vendor payment.');
                }
            }
        }
        
        // Load views based on user role
        if ($this->session->userdata('role') === 'admin') {
            $this->load->view('admin/includes/header', $data);
            $this->load->view('admin/includes/sidebar');
            $this->load->view('vendor_payments/form', $data);
            $this->load->view('admin/includes/footer');
        } else {
            $this->load->view('staff/includes/header', $data);
            $this->load->view('staff/includes/sidebar');
            $this->load->view('vendor_payments/form', $data);
            $this->load->view('staff/includes/footer');
        }
    }
    
    // Edit payment
    public function edit($id) {
        $data['title'] = 'Edit Vendor Payment';
        $data['active_page'] = 'vendor_payments';
        $data['payment'] = $this->Vendor_payments_model->get_payment_by_id($id);
        $data['modes'] = $this->Vendor_payments_model->get_payment_modes();
        $data['statuses'] = $this->Vendor_payments_model->get_payment_statuses();
        $data['vendors'] = $this->Vendor_model->get_active_vendors();
        
        // Set notification counts for staff sidebar
        if ($this->session->userdata('role') === 'staff') {
            $this->set_notification_counts($data);
        }
        
        if (!$data['payment']) {
            $this->session->set_flashdata('error', 'Payment record not found.');
            redirect('vendor_payments');
        }
        
        if ($this->input->post()) {
            $this->form_validation->set_rules('date', 'Date', 'required');
            $this->form_validation->set_rules('sender', 'Sender', 'required|trim');
            $this->form_validation->set_rules('receiver', 'Receiver', 'required|trim');
            $this->form_validation->set_rules('mode', 'Payment Mode', 'required|in_list[Zelle,Cash App,Venmo]');
            $this->form_validation->set_rules('amount', 'Amount', 'required|trim');
            $this->form_validation->set_rules('status', 'Status', 'required|in_list[Pending,Approved,Declined]');
            $this->form_validation->set_rules('vendor_id', 'Vendor', 'required|numeric');
            
            if ($this->form_validation->run() == TRUE) {
                $payment_data = array(
                    'date' => $this->input->post('date'),
                    'sender' => $this->input->post('sender'),
                    'receiver' => $this->input->post('receiver'),
                    'mode' => $this->input->post('mode'),
                    'amount' => $this->input->post('amount'),
                    'status' => $this->input->post('status'),
                    'vendor_id' => $this->input->post('vendor_id')
                );
                
                if ($this->Vendor_payments_model->update_payment($id, $payment_data)) {
                    $this->session->set_flashdata('success', 'Vendor payment updated successfully.');
                    redirect('vendor_payments');
                } else {
                    $this->session->set_flashdata('error', 'Failed to update vendor payment.');
                }
            }
        }
        
        // Load views based on user role
        if ($this->session->userdata('role') === 'admin') {
            $this->load->view('admin/includes/header', $data);
            $this->load->view('admin/includes/sidebar');
            $this->load->view('vendor_payments/form', $data);
            $this->load->view('admin/includes/footer');
        } else {
            $this->load->view('staff/includes/header', $data);
            $this->load->view('staff/includes/sidebar');
            $this->load->view('vendor_payments/form', $data);
            $this->load->view('staff/includes/footer');
        }
    }
    
    // Delete payment
    public function delete($id) {
        // Only admin can delete payments
        if ($this->session->userdata('role') !== 'admin') {
            $this->session->set_flashdata('error', 'Access denied. Only administrators can delete payment records.');
            redirect('vendor_payments');
        }
        
        $payment = $this->Vendor_payments_model->get_payment_by_id($id);
        
        if (!$payment) {
            $this->session->set_flashdata('error', 'Payment record not found.');
        } else {
            if ($this->Vendor_payments_model->delete_payment($id)) {
                $this->session->set_flashdata('success', 'Vendor payment deleted successfully.');
            } else {
                $this->session->set_flashdata('error', 'Failed to delete vendor payment.');
            }
        }
        
        redirect('vendor_payments');
    }
    
    // View payment details
    public function view($id) {
        $data['title'] = 'View Vendor Payment';
        $data['active_page'] = 'vendor_payments';
        $data['payment'] = $this->Vendor_payments_model->get_payment_by_id($id);
        
        // Set notification counts for staff sidebar
        if ($this->session->userdata('role') === 'staff') {
            $this->set_notification_counts($data);
        }
        
        if (!$data['payment']) {
            $this->session->set_flashdata('error', 'Payment record not found.');
            redirect('vendor_payments');
        }
        
        // Load views based on user role
        if ($this->session->userdata('role') === 'admin') {
            $this->load->view('admin/includes/header', $data);
            $this->load->view('admin/includes/sidebar');
            $this->load->view('vendor_payments/view', $data);
            $this->load->view('admin/includes/footer');
        } else {
            $this->load->view('staff/includes/header', $data);
            $this->load->view('staff/includes/sidebar');
            $this->load->view('vendor_payments/view', $data);
            $this->load->view('staff/includes/footer');
        }
    }
    
    // Export to CSV
    public function export() {
        $filters = array(
            'vendor' => $this->input->get('vendor'),
            'status' => $this->input->get('status'),
            'mode' => $this->input->get('mode'),
            'date_from' => $this->input->get('date_from'),
            'date_to' => $this->input->get('date_to')
        );
        
        $payments = $this->Vendor_payments_model->get_all_payments(1000, 0, $filters);
        
        // Set headers for CSV download
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="vendor_payments_' . date('Y-m-d') . '.csv"');
        
        // Create output stream
        $output = fopen('php://output', 'w');
        
        // Add CSV headers
        fputcsv($output, array('Date', 'Sender', 'Receiver', 'Mode', 'Amount', 'Status', 'Vendor', 'Created By', 'Created At'));
        
        // Add data rows
        foreach ($payments as $payment) {
            fputcsv($output, array(
                $payment->date,
                $payment->sender,
                $payment->receiver,
                $payment->mode,
                '$' . number_format($payment->amount, 2),
                $payment->status,
                $payment->vendor,
                $payment->creator_first_name . ' ' . $payment->creator_last_name,
                $payment->created_at
            ));
        }
        
        fclose($output);
        exit;
    }

    // Update payment status (AJAX)
    public function update_status() {
        // Check if it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            show_404();
        }
        
        $payment_id = $this->input->post('payment_id');
        $status = $this->input->post('status');
        
        // Validate inputs
        if (!$payment_id || !$status) {
            $this->output->set_content_type('application/json')
                         ->set_output(json_encode(['success' => false, 'message' => 'Missing required parameters']));
            return;
        }
        
        // Validate status
        $valid_statuses = ['Pending', 'Approved', 'Declined'];
        if (!in_array($status, $valid_statuses)) {
            $this->output->set_content_type('application/json')
                         ->set_output(json_encode(['success' => false, 'message' => 'Invalid status']));
            return;
        }
        
        // Get the payment record
        $payment = $this->Vendor_payments_model->get_payment_by_id($payment_id);
        if (!$payment) {
            $this->output->set_content_type('application/json')
                         ->set_output(json_encode(['success' => false, 'message' => 'Payment not found']));
            return;
        }
        
        // Update the payment status
        $update_data = array('status' => $status);
        if ($this->Vendor_payments_model->update_payment($payment_id, $update_data)) {
            $this->output->set_content_type('application/json')
                         ->set_output(json_encode(['success' => true, 'message' => 'Payment status updated successfully']));
        } else {
            $this->output->set_content_type('application/json')
                         ->set_output(json_encode(['success' => false, 'message' => 'Failed to update payment status']));
        }
    }
} 