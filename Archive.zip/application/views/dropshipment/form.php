<?php $this->load->view('admin/includes/header'); ?>

<div class="main-content">
    <div class="container-fluid">
        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-0 text-gray-800">
                    <i class="fas fa-plus me-2"></i>Add Drop Shipment Order
                </h1>
                <p class="text-muted">Create a new drop shipment order</p>
            </div>
            <div>
                <a href="<?php echo base_url('dropshipment'); ?>" class="btn btn-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Back to Orders
                </a>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-8">
                <div class="card shadow">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Order Details</h6>
                    </div>
                    <div class="card-body">
                        <?php if (validation_errors()): ?>
                            <div class="alert alert-danger">
                                <i class="fas fa-exclamation-triangle me-1"></i>
                                Please correct the following errors:
                                <?php echo validation_errors(); ?>
                            </div>
                        <?php endif; ?>

                        <?php echo form_open('dropshipment/add'); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="customer_name">Customer Name <span class="text-danger">*</span></label>
                                        <input type="text" name="customer_name" id="customer_name" class="form-control" 
                                               value="<?php echo set_value('customer_name'); ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="customer_email">Customer Email</label>
                                        <input type="email" name="customer_email" id="customer_email" class="form-control" 
                                               value="<?php echo set_value('customer_email'); ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="customer_phone">Customer Phone</label>
                                        <input type="text" name="customer_phone" id="customer_phone" class="form-control" 
                                               value="<?php echo set_value('customer_phone'); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="center">Center <span class="text-danger">*</span></label>
                                        <select name="center" id="center" class="form-control" required>
                                            <option value="">Select Center</option>
                                            <?php foreach ($centers as $center): ?>
                                                <option value="<?php echo $center->name; ?>" <?php echo set_select('center', $center->name); ?>>
                                                    <?php echo $center->name; ?>
                                                    <?php if ($center->location): ?>
                                                        (<?php echo $center->location; ?>)
                                                    <?php endif; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="customer_address">Customer Address</label>
                                <textarea name="customer_address" id="customer_address" class="form-control" rows="3"><?php echo set_value('customer_address'); ?></textarea>
                            </div>

                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label for="product_name">Product Name <span class="text-danger">*</span></label>
                                        <input type="text" name="product_name" id="product_name" class="form-control" 
                                               value="<?php echo set_value('product_name'); ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="quantity">Quantity <span class="text-danger">*</span></label>
                                        <input type="number" name="quantity" id="quantity" class="form-control" 
                                               value="<?php echo set_value('quantity', 1); ?>" min="1" required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="notes">Notes</label>
                                <textarea name="notes" id="notes" class="form-control" rows="3" 
                                          placeholder="Any additional notes about this order..."><?php echo set_value('notes'); ?></textarea>
                            </div>

                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save me-1"></i>Create Order
                                </button>
                                <a href="<?php echo base_url('dropshipment'); ?>" class="btn btn-secondary">
                                    <i class="fas fa-times me-1"></i>Cancel
                                </a>
                            </div>
                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card shadow">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Order Information</h6>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <h6><i class="fas fa-info-circle me-1"></i>Order Status</h6>
                            <p class="mb-0">New orders will be created with <strong>Pending</strong> status. Admin users can then process them and set pricing.</p>
                        </div>

                        <div class="alert alert-warning">
                            <h6><i class="fas fa-exclamation-triangle me-1"></i>Important Notes</h6>
                            <ul class="mb-0">
                                <li>Order numbers are auto-generated</li>
                                <li>Only admin users can process orders and set prices</li>
                                <li>Tracking information can be added later</li>
                                <li>Orders are assigned to specific centers</li>
                            </ul>
                        </div>

                        <div class="alert alert-success">
                            <h6><i class="fas fa-check-circle me-1"></i>Available Centers</h6>
                            <ul class="mb-0">
                                <?php foreach ($centers as $center): ?>
                                    <li><strong><?php echo $center->name; ?></strong>
                                        <?php if ($center->location): ?>
                                            <br><small class="text-muted"><?php echo $center->location; ?></small>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Auto-resize textareas
document.addEventListener('DOMContentLoaded', function() {
    const textareas = document.querySelectorAll('textarea');
    textareas.forEach(function(textarea) {
        textarea.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = this.scrollHeight + 'px';
        });
    });
});
</script>

<?php $this->load->view('admin/includes/footer'); ?> 