<?php $this->load->view('admin/includes/header'); ?>

<div class="main-content">
    <div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800">
                <i class="fas fa-shipping-fast me-2"></i>Drop Shipment Orders
            </h1>
            <p class="text-muted">Manage drop shipment orders and track their status</p>
        </div>
        <div>
            <a href="<?php echo base_url('dropshipment/add'); ?>" class="btn btn-primary">
                <i class="fas fa-plus me-1"></i>Add New Order
            </a>
        </div>
    </div>

    <!-- Summary Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Orders</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $order_summary->total_orders ?? 0; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-boxes fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Pending Orders</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $order_summary->pending_count ?? 0; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clock fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Processed Orders</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $order_summary->processed_count ?? 0; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Amount</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">₹<?php echo number_format($order_summary->total_amount ?? 0, 2); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Filters</h6>
        </div>
        <div class="card-body">
            <form method="GET" action="<?php echo base_url('dropshipment'); ?>">
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select name="status" id="status" class="form-control">
                                <option value="">All Statuses</option>
                                <?php foreach ($statuses as $status): ?>
                                    <option value="<?php echo $status; ?>" <?php echo ($filters['status'] === $status) ? 'selected' : ''; ?>>
                                        <?php echo $status; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="center">Center</label>
                            <select name="center" id="center" class="form-control">
                                <option value="">All Centers</option>
                                <?php foreach ($centers as $center): ?>
                                    <option value="<?php echo $center->name; ?>" <?php echo ($filters['center'] === $center->name) ? 'selected' : ''; ?>>
                                        <?php echo $center->name; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="date_from">Date From</label>
                            <input type="date" name="date_from" id="date_from" class="form-control" value="<?php echo $filters['date_from']; ?>">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="date_to">Date To</label>
                            <input type="date" name="date_to" id="date_to" class="form-control" value="<?php echo $filters['date_to']; ?>">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="search">Search</label>
                            <input type="text" name="search" id="search" class="form-control" placeholder="Order #, Customer, Product" value="<?php echo $filters['search']; ?>">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <div>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search me-1"></i>Filter
                                </button>
                                <a href="<?php echo base_url('dropshipment'); ?>" class="btn btn-secondary">
                                    <i class="fas fa-times me-1"></i>Clear
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Center Summary -->
    <?php if (!empty($center_summary)): ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Center Summary</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Center</th>
                            <th>Total Orders</th>
                            <th>Pending</th>
                            <th>Processed</th>
                            <th>Shipped</th>
                            <th>Delivered</th>
                            <th>Cancelled</th>
                            <th>Total Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($center_summary as $summary): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($summary->center); ?></strong></td>
                            <td><?php echo $summary->total_orders; ?></td>
                            <td><span class="badge bg-warning"><?php echo $summary->pending_count; ?></span></td>
                            <td><span class="badge bg-success"><?php echo $summary->processed_count; ?></span></td>
                            <td><span class="badge bg-info"><?php echo $summary->shipped_count; ?></span></td>
                            <td><span class="badge bg-primary"><?php echo $summary->delivered_count; ?></span></td>
                            <td><span class="badge bg-danger"><?php echo $summary->cancelled_count; ?></span></td>
                            <td><strong>₹<?php echo number_format($summary->total_amount, 2); ?></strong></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Orders Table -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Drop Shipment Orders</h6>
        </div>
        <div class="card-body">
            <?php if (empty($orders)): ?>
                <div class="text-center py-4">
                    <i class="fas fa-box-open fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">No orders found</h5>
                    <p class="text-muted">No drop shipment orders match your current filters.</p>
                    <a href="<?php echo base_url('dropshipment/add'); ?>" class="btn btn-primary">
                        <i class="fas fa-plus me-1"></i>Add First Order
                    </a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Order #</th>
                                <th>Customer</th>
                                <th>Product</th>
                                <th>Center</th>
                                <th>Status</th>
                                <th>Price</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $order): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($order->order_number); ?></strong>
                                </td>
                                <td>
                                    <div><?php echo htmlspecialchars($order->customer_name); ?></div>
                                    <?php if ($order->customer_email): ?>
                                        <small class="text-muted"><?php echo htmlspecialchars($order->customer_email); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div><?php echo htmlspecialchars($order->product_name); ?></div>
                                    <small class="text-muted">Qty: <?php echo $order->quantity; ?></small>
                                </td>
                                <td><?php echo htmlspecialchars($order->center); ?></td>
                                <td>
                                    <?php if ($order->status === 'Pending'): ?>
                                        <span class="badge bg-warning"><?php echo $order->status; ?></span>
                                    <?php elseif ($order->status === 'Processed'): ?>
                                        <span class="badge bg-success"><?php echo $order->status; ?></span>
                                    <?php elseif ($order->status === 'Shipped'): ?>
                                        <span class="badge bg-info"><?php echo $order->status; ?></span>
                                    <?php elseif ($order->status === 'Delivered'): ?>
                                        <span class="badge bg-primary"><?php echo $order->status; ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-danger"><?php echo $order->status; ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($order->price): ?>
                                        <strong>₹<?php echo number_format($order->price, 2); ?></strong>
                                    <?php else: ?>
                                        <span class="text-muted">Not set</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div><?php echo date('M j, Y', strtotime($order->created_at)); ?></div>
                                    <small class="text-muted"><?php echo date('g:i A', strtotime($order->created_at)); ?></small>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="<?php echo base_url('dropshipment/view/' . $order->id); ?>" class="btn btn-outline-info btn-sm" title="View">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        
                                        <?php if ($this->session->userdata('role') === 'admin' && $order->status === 'Pending'): ?>
                                            <a href="<?php echo base_url('dropshipment/process/' . $order->id); ?>" class="btn btn-outline-success btn-sm" title="Process">
                                                <i class="fas fa-check"></i>
                                            </a>
                                        <?php endif; ?>
                                        
                                        <?php if ($this->session->userdata('role') === 'admin'): ?>
                                            <button type="button" class="btn btn-outline-danger btn-sm" title="Delete" 
                                                    onclick="deleteOrder(<?php echo $order->id; ?>)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($pagination): ?>
                    <div class="mt-4">
                        <?php echo $pagination; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function deleteOrder(orderId) {
    if (confirm('Are you sure you want to delete this order? This action cannot be undone.')) {
        window.location.href = '<?php echo base_url('dropshipment/delete/'); ?>' + orderId;
    }
}
</script>

<?php $this->load->view('admin/includes/footer'); ?> 